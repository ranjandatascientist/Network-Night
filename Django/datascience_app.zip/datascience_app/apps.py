from django.apps import AppConfig


class DatascienceAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'datascience_app'
