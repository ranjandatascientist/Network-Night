from django.shortcuts import render, redirect
from django.contrib import messages
from django.utils import timezone
from .models import User, UserSession
from .forms import UserCreationForm, AuthenticationForm
import uuid

def home(request):
    return render(request, 'index.html')

def login_signup(request):
    return render(request, 'login_signup.html')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        
        # Debugging: Print form data and validation status
        print("Form data:", request.POST)
        print("Form valid:", form.is_valid())
        print("Form errors:", form.errors)
        
        if form.is_valid():
            user = form.save(commit=False)
            
            # Set the password using the model's method
            user.set_password(form.cleaned_data['password'])
            user.save()
            
            messages.success(request, "Account created successfully!")
            return redirect('loginSignup')
        else:
            messages.error(request, 'Error creating account. Please check the form.')
    else:
        form = UserCreationForm()
        
    return render(request, 'login_signup.html', {'form': form})

def login(request):
    if request.method == 'POST':
        print("POST request received")
        form = AuthenticationForm(request, data=request.POST)
        
        if form.is_valid():
            print("Form is valid")
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            print(f"Username: {username}")
            print(f"Password: {password}")

            try:
                user = User.objects.get(Username=username)
                print("User found")
                if user.check_password(password):
                    print("Password is correct")
                    session_token = str(uuid.uuid4())
                    
                    # Create a new session for the user
                    UserSession.objects.create(
                        UserID=user,
                        SessionToken=session_token,
                        ExpireDate=timezone.now() + timezone.timedelta(hours=7),
                        IpAddress=request.META.get('REMOTE_ADDR'),
                        UserAgent=request.META.get('HTTP_USER_AGENT')
                    )
                    
                    # Store session token in Django session framework
                    request.session['session_token'] = session_token
                    messages.success(request, 'Logged in successfully!')
                    print("Redirecting to home")
                    return redirect('home')
                else:
                    print("Invalid password")
                    messages.error(request, 'Invalid Username or Password')
            except User.DoesNotExist:
                print("User does not exist")
                messages.error(request, 'Invalid Username or Password')
        else:
            print("Form is not valid")
            print(form.errors)
    else:
        print("GET request received")
        form = AuthenticationForm()

    return render(request, 'login_signup.html', {'form': form})

def logout(request):
    session_token = request.session.pop('session_token', None)
    
    if session_token:
        # Delete the session from the database
        UserSession.objects.filter(SessionToken=session_token).delete()
    
    messages.success(request, 'Logged out successfully!')
    return redirect('loginSignup')
